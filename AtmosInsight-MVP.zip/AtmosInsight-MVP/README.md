# AtmosInsight – MVP

Minimal prototype for NASA Space Apps: a **web viewer** for NASA GIBS layers plus a **podcast-style narration** using **Google Cloud Text-to-Speech**.

## Run locally

1) Install deps:
```bash
npm i
```

2) Set Google credentials (service account with Cloud Text-to-Speech enabled):
```bash
export GOOGLE_APPLICATION_CREDENTIALS=./service-account.json
```

3) Start:
```bash
npm start
```

4) Open:
```
http://localhost:8787
```

- Click **Generate Narration** to synthesize speech.
- Choose **Voice** (English US/UK, Español ES/CO).

## Notes

- Tiles URL template (WMTS, EPSG:3857):
```
https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/{LAYER}/default/{DATE}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.png
```
- Default center: Bogotá.
- You can deploy on any Node host (Render, Railway, GCP App Engine). For static hosting + separate TTS, serve `index.html` and run `server.js` elsewhere (update endpoint in `app.js`).
