// --- Configurable backend base URL via DevTools ---
// Example in browser console: window.__AI_BACKEND__ = "http://localhost:8787";
const BACKEND_BASE_URL = (typeof window !== "undefined" && window.__AI_BACKEND__) || "";

// --- Catalog of layers ---
const LAYERS = [
  {
    key: "MODIS_Terra_CorrectedReflectance_TrueColor",
    label: "MODIS Terra – True Color (Optical)",
    category: "land",
    maxZoom: 9,
  },
  {
    key: "MERRA2_2m_Air_Temperature_Monthly",
    label: "MERRA‑2 – 2m Air Temperature (Atmosphere)",
    category: "atmosphere",
    maxZoom: 9,
  },
  {
    key: "OPERA_L3_Dynamic_Surface_Water_Extent-HLS",
    label: "OPERA – Surface Water Extent (Radar)",
    category: "water",
    maxZoom: 9,
  },
];

// Sensible default date (yesterday UTC)
function isoYesterdayUTC() {
  const now = new Date();
  const utc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  const y = new Date(utc - 24 * 60 * 60 * 1000);
  return y.toISOString().slice(0, 10);
}

// NASA GIBS WMTS URL
function gibsUrl(layerId, dateIso) {
  return `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/${layerId}/default/${dateIso}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.png`;
}

// Try real backend (prefer BACKEND_BASE_URL). Ignore 404/405 until a good candidate is found.
async function tryRealNarrateEndpoint(body) {
  const candidates = [];
  if (BACKEND_BASE_URL) {
    const base = BACKEND_BASE_URL.replace(/\/$/, "");
    candidates.push(`${base}/narrate`, `${base}/api/narrate`);
  } else {
    candidates.push("/narrate", "/api/narrate");
  }
  const errors = [];
  for (const url of candidates) {
    try {
      const r = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body ?? { text: "Hello from AtmosInsight", lang: "en-US" }),
      });
      if (r.ok) return { ok: true, status: r.status, url, response: r };
      if (r.status === 405 || r.status === 404) { errors.push(`${url} -> HTTP ${r.status}`); continue; }
      return { ok: false, status: r.status, url, response: r, errors };
    } catch (e) {
      errors.push(`${url} -> ${String(e)}`);
      continue;
    }
  }
  return { ok: false, status: 0, url: "(none)", errors };
}

// Mock narration (Web Speech API)
function speakMock(text, lang = "en-US", rate = 1.06) {
  if (!("speechSynthesis" in window)) throw new Error("SpeechSynthesis not available");
  const u = new SpeechSynthesisUtterance(text);
  u.lang = lang; u.rate = rate;
  window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
}

// Auto language
function autoLangForLayer(category) {
  return category === "atmosphere" ? { lang: "en-US" } : { lang: "es-ES" };
}

// Self-tests
async function runSelfTests({ layer, date }) {
  const results = [];
  const today = new Date().toISOString().slice(0, 10);
  results.push({ name: "Date not in the future", pass: date <= today, detail: `${date} <= ${today}` });
  const url = gibsUrl(layer.key, date);
  results.push({ name: "GIBS URL pattern", pass: url.includes("GoogleMapsCompatible_Level9"), detail: url });
  const need = ["MODIS_Terra_CorrectedReflectance_TrueColor", "MERRA2_2m_Air_Temperature_Monthly"];
  results.push({ name: "Catalog essentials", pass: need.every(k => LAYERS.find(l => l.key === k)), detail: need.join(", ") });
  results.push({ name: "SpeechSynthesis available", pass: "speechSynthesis" in window, detail: "mock capable" });
  return results;
}

// --- App state ---
let map, currentTile;
const elLayer = document.getElementById("layer");
const elDate = document.getElementById("date");
const elMock = document.getElementById("mockTts");
const elProbe = document.getElementById("probe");
const elBadge = document.getElementById("badge");
const elTests = document.getElementById("tests");

// Fill layer select
LAYERS.forEach(l => {
  const opt = document.createElement("option");
  opt.value = l.key; opt.textContent = l.label;
  elLayer.appendChild(opt);
});
elLayer.value = LAYERS[0].key;
elDate.value = isoYesterdayUTC();

// Init map
function initMap() {
  map = L.map("map", { center: [4.6, -74.1], zoom: 5 });
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(map);
  updateGibsLayer();
}
function updateGibsLayer() {
  const layer = LAYERS.find(l => l.key === elLayer.value);
  const dateIso = elDate.value;
  const url = gibsUrl(layer.key, dateIso);
  if (currentTile) map.removeLayer(currentTile);
  currentTile = L.tileLayer(url, { maxZoom: layer.maxZoom || 9, crossOrigin: true }).addTo(map);
  elBadge.textContent = `${layer.label} — ${dateIso}`;
}
initMap();

// Events
elLayer.addEventListener("change", updateGibsLayer);
elDate.addEventListener("change", updateGibsLayer);

document.getElementById("btnNarrate").addEventListener("click", async () => {
  const layer = LAYERS.find(l => l.key === elLayer.value);
  const dateIso = elDate.value;
  const { lang } = autoLangForLayer(layer.category);
  const textEN = `AtmosInsight: Displaying ${layer.label} for ${dateIso}.`;
  const textES = `AtmosInsight: Mostrando ${layer.label} para ${dateIso}.`;
  const text = lang.startsWith("en") ? textEN : textES;

  if (elMock.checked) {
    try { speakMock(text, lang, 1.06); } catch (e) { alert("Mock TTS not available."); }
    return;
  }

  const resp = await tryRealNarrateEndpoint({ text, lang });
  if (!resp.ok) { try { speakMock(text, lang, 1.06); } catch (e) { alert(`TTS backend failed (${resp.status}).`); } return; }

  try {
    const ctype = resp.response.headers.get("content-type") || "";
    let audioUrl = null;
    if (ctype.includes("application/json")) {
      const data = await resp.response.json();
      const b64 = data.audioContent || data.audio || "";
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      audioUrl = URL.createObjectURL(new Blob([bytes], { type: "audio/mpeg" }));
    } else {
      const blob = await resp.response.blob();
      audioUrl = URL.createObjectURL(blob);
    }
    const audio = new Audio(audioUrl);
    audio.play();
  } catch (e) {
    try { speakMock(text, lang, 1.06); } catch (_) { alert("Could not play TTS."); }
  }
});

document.getElementById("btnProbe").addEventListener("click", async () => {
  elProbe.textContent = "Probing...";
  const res = await tryRealNarrateEndpoint({ text: "Probe", lang: "en-US" });
  if (res.ok) {
    elProbe.innerHTML = `<b>Endpoint:</b> ${res.url}<br/><b>Status:</b> ${res.status}`;
  } else {
    elProbe.innerHTML = `<b>Endpoint:</b> ${res.url}<br/><b>Status:</b> ${res.status}<pre>${(res.errors||[]).join("\n")}</pre>`;
  }
});

document.getElementById("btnTests").addEventListener("click", async () => {
  elTests.innerHTML = "Running…";
  const layer = LAYERS.find(l => l.key === elLayer.value);
  const dateIso = elDate.value;
  const results = await runSelfTests({ layer, date: dateIso });
  elTests.innerHTML = "";
  results.forEach(r => {
    const li = document.createElement("li");
    li.className = r.pass ? "pass" : "fail";
    li.innerHTML = `<b>${r.name}:</b> ${r.pass ? "PASS" : "FAIL"} — <span style="opacity:.8">${r.detail}</span>`;
    elTests.appendChild(li);
  });
});
