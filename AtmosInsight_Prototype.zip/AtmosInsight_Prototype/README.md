# AtmosInsight — Prototype (NASA GIBS + Narration)

This package contains a minimal **functional prototype** demonstrating how open satellite data can be turned into an interactive map and narrated experience.

## Structure
```
AtmosInsight_Prototype/
├─ client/        # Static web app (Leaflet + NASA GIBS)
│  ├─ index.html
│  ├─ styles.css
│  └─ app.js
└─ server/        # Express stub exposing POST /narrate
   ├─ package.json
   └─ server.js
```

## Run (Local)

### 1) Start the TTS stub (optional but recommended)
```bash
cd server
npm install
npm start   # runs on http://localhost:8787
```

### 2) Serve the client folder
Use any static server. Examples:
```bash
# Python
cd ../client
python3 -m http.server 8080

# or Node (if you have serve installed)
# npm i -g serve
# serve -l 8080 .
```

Open: http://localhost:8080

## How it works
- The **client** loads a Leaflet map and NASA GIBS layers via WMTS.
- The **Generate Narration** button will:
  - Use **Mock Narration** (Web Speech API) when the toggle is ON.
  - When OFF, it tries POST `/narrate` on:
    - `window.__AI_BACKEND__/narrate` and `window.__AI_BACKEND__/api/narrate` (if you set it),
    - then relative `/narrate` and `/api/narrate`,
    - ignoring HTTP 404/405 until a working endpoint is found.
- The **server** folder ships a minimal Express stub responding 200 on `/narrate`. Replace the handler with a real TTS provider later.

## Configure real backend (optional)
In the browser console (on the client page), set:
```js
window.__AI_BACKEND__ = "http://localhost:8787";
```
Press **Test Real Backend**. If it shows Status 200, disable **Mock Narration** and generate narration.
