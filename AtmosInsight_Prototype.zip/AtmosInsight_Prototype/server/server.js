import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

// Minimal stub: returns empty MP3 (for status 200). Replace with real TTS if available.
app.post("/narrate", async (req, res) => {
  const { text = "Hello from AtmosInsight", lang = "en-US" } = req.body || {};
  res.setHeader("Content-Type", "audio/mpeg");
  res.send(Buffer.from([])); // replace with real audio if desired
});

app.get("/health", (_, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => console.log(`TTS stub running at http://localhost:${PORT}`));
